package events;

public interface SatelitteMoveListener {
	public void whenSatelitteMoved(SatelliteMoved arg);
}
