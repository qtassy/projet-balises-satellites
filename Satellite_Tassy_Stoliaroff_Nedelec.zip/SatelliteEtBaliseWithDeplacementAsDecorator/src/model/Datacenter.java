package model;

public class Datacenter extends Model {
	public void tick() {
		
	}
}
