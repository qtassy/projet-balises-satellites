package views;

import events.PositionChangeListener;
import events.SynchroEventListener;
import nicellipse.component.NiRectangle;

public abstract class GrModel extends NiRectangle implements PositionChangeListener, SynchroEventListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9076312960026105984L;

}
